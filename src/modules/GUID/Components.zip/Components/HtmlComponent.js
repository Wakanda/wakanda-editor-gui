import functUtils from '../functUtils';
import Component from './Component';

var htmlComponent = {
	'div': {
		'name': "div",
		// no import
		'attributes': [],
		'styling': [{
			'name': 'margin',
			'type': 'margin'
		}, {
			'name': 'padding',
			'type': 'padding'
		}, {
			'name': 'border',
			'type': 'border'
		}],
		creationStep: functUtils.fillwithName
	},
	'a': {
		'name': "a",
		// no import
		'attributes': [{
			'name': 'href',
			'type': 'string', //TODO see if its better to change it to select
			'defeaultValue': '/#'
		}],
		creationStep: functUtils.fillwithName
	},
	'span': {
		'name': "Span",
		// no import
		'attributes': [],
		creationStep: functUtils.fillwithName
	},
	'img': {
		'name': "Img",
		// no import
		'attributes': [{
				'name': 'src',
				'type': 'string',
				'defeaultValue': '/src/wakanda.jpg'
			}, {
				'name': 'alt',
				'type': 'string',
				'defeaultValue': 'Alternate text'
			}
			// TODO height & width in styling
		],
		'styling': [{
			'name': 'margin',
			'type': 'margin'
		}, {
			'name': 'padding',
			'type': 'padding'
		}, {
			'name': 'border',
			'type': 'border'
		}],
		creationStep: undefined
	}
};

class HtmlComponent extends Component{
	constructor(){
		//TODO get it via ajax or another file
		this.components = HtmlComponent;
	}

	get componentType(){
		return 'html';
	}

	renderComponent(componentName, fillWith) {
			var htmlComponent = this.components[componentName];

			var node = DOCUMENT.createElement(componentName);

			htmlComponent.attributes.forEach(function(attr) {
				if (attr['defeaultValue'] !== undefined) {
					node.setAttribute(attr['name'], attr['defeaultValue']);
				}
			});

			node = (htmlComponent.creationStep || functUtils.identity)(node, fillWith);

			return node;
	}

}

export default HtmlComponent;
