import functUtils from '../functUtils';

class Components {
	constructor(doc, ...args) {
		this.components  = [];
	}

	exists(tagName) {
		return this.Components[tagName] !== undefined;
	}

	getComponent(componentName) {
		return this.components[componentName];
	}

	hasAttribute(tagName, attName) {
		var component = this.components[tagName] || {
			'attributes': []
		}

		var attributesName = (component.attributes || []).map(functUtils.mapNameOfObject);

		return (-1 !== attributesName.indexOf(attName));
	}

	renderPolymerComponent(componentName) {
		var polymerWidget = this.polymerComponents[componentName];

		window.importedLinks.addPolymerWidget(polymerWidget);
		//TODO : remove rel when widget is deleted

		var node = DOCUMENT.createElement(componentName);

		polymerWidget.attributes.forEach(function(attr) {
			if (attr['defeaultValue'] !== undefined) {
				node[attr['name']] = attr['defeaultValue'];
				//node.setAttribute(attr['name'], attr['defeaultValue']);
			}
		});

		return node;
	}

	getComponentsNames(){
		return Object.keys(this.components);
	}

}
